// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerCharacter.h"
#include "Blueprint/UserWidget.h"

/*
* Source file for PlayerCharacter class, which manages player behavior
* Owyn Lee, Anakin Schneider
*/

APlayerCharacter::APlayerCharacter()
{
 	// Request the Pawn to run its tick function every frame
	PrimaryActorTick.bCanEverTick = true;

	// Create a capsule collider at the Pawn's position
	CapsuleComponent = CreateDefaultSubobject<UCapsuleComponent>(TEXT("RootCapsule"));
	CapsuleComponent->InitCapsuleSize(30.f, 90.f);
	CapsuleComponent->SetCollisionProfileName(TEXT("Pawn"));
	RootComponent = CapsuleComponent;
}

void APlayerCharacter::BeginPlay()
{
	// Call the superclass (Pawn)'s beginplay function
	Super::BeginPlay();

	// Create a widget https://www.youtube.com/watch?v=ACIQcOgqWLI
	if (IsValid(WidgetReference))
	{
		createdWidget = CreateWidget(GetWorld(), WidgetReference);
	}
	if (IsValid(createdWidget)) {
		createdWidget->AddToViewport();
	}
	if (GEngine && GEngine->GameViewport)
	{
		// Set the ViewMode to Unlit (Index 2)
		GEngine->GameViewport->ViewModeIndex = VMI_Unlit;

		// Update engine show flags to match the unlit view mode
		ApplyViewMode(VMI_Unlit, true, GEngine->GameViewport->EngineShowFlags);
	}
	
}

void APlayerCharacter::Tick(float DeltaTime)
{
	// Call the superclass (Pawn)'s tick function
	Super::Tick(DeltaTime);
	// Output a log message to verify that this script is running ingame
	UE_LOG(LogTemp, Warning, TEXT("This Owyn Lee's debug warning message."));

	// Collide and Slide based movement controller. 
	// Follows Collide and Slide tutorial by Poke Dev "https://www.youtube.com/watch?v=YR6Q7dUz2uk"
	if (!CurrentVelocity.IsZero()) {
		// Detect impending geometry collisions by raycasting the player's predicted location
		FVector DeltaLocation = CurrentVelocity * DeltaTime; // Predicted location of the player
		FHitResult Hit; // Storage variable for collision information

		// Relocate the player to their predicted location with bSweep set to true. If the sweep's raycast hits a surface, the player will stop at the impact point
		// Collisions will populate Hit with information regarding the surface the player collided with
		AddActorLocalOffset(DeltaLocation, true, &Hit);

		// Due to how bSweep works, the player will lose all of their momentum if they brush against a surface
		// This unsatisfying behavior can be resolved by applying a slide offset
		if (Hit.IsValidBlockingHit())
		{
			// Project the player's movement vector along the geometry's planar surface normal (retrieved via Hit). 
			// This will channel their remaining velocity along the wall's surface instead of erasing it
			FVector SlideDelta = FVector::VectorPlaneProject(DeltaLocation, Hit.Normal) * (1.f - Hit.Time);
			
			// Apply the slide vector to the player's position, letting them slide along the surface
			AddActorLocalOffset(SlideDelta, true);
		}
	}
}

void APlayerCharacter::MoveX(float AxisInput) {
	// Register horizontal player input (A,D)
	CurrentVelocity.X = FMath::Clamp(AxisInput, -1.0f, 1.0f) * MovementSpeed;
}

void APlayerCharacter::MoveY(float AxisInput) {
	// Register vertical player input (W,S)
	CurrentVelocity.Y = FMath::Clamp(AxisInput, -1.0f, 1.0f) * MovementSpeed;
}

void APlayerCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) {
	// To let the player character move, register MoveX and MoveY functions in PlayerInputComponent
	// MoveForward (W = 1.0, S = -1.0) and MoveRight (A = -1.0, D = 1.0) need to be registered in Project Settings -> Input -> Axis Mappings
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	PlayerInputComponent->BindAxis("MoveForward", this, &APlayerCharacter::MoveX);
	PlayerInputComponent->BindAxis("MoveRight", this, &APlayerCharacter::MoveY);
}